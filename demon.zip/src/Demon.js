import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Demon() {
  const [clients, setClients] = useState([
    { id: 1, name: "AB Blåbär", orgnr: "556123-4567" },
    { id: 2, name: "Kalles Städservice", orgnr: "750101-1234" },
    { id: 3, name: "Redovisning & Co", orgnr: "969696-7890" },
  ]);

  const [selectedClient, setSelectedClient] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [entry, setEntry] = useState({ date: "", description: "", debit: "", credit: "" });

  const handleUpload = (e) => {
    const file = e.target.files[0];
    if (file) setInvoice(file);
  };

  const handleCreateEntry = () => {
    alert("Verifikation skapad: " + JSON.stringify(entry));
    setEntry({ date: "", description: "", debit: "", credit: "" });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
      <Card>
        <CardContent className="space-y-4">
          <h2 className="text-xl font-bold">Klienter</h2>
          <ul>
            {clients.map((client) => (
              <li key={client.id}>
                <Button onClick={() => setSelectedClient(client)} variant="outline">
                  {client.name}
                </Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {selectedClient && (
        <Card>
          <CardContent className="space-y-4">
            <h2 className="text-xl font-bold">{selectedClient.name}</h2>

            <div className="space-y-2">
              <label className="font-semibold">Ladda upp faktura (PDF):</label>
              <Input type="file" accept="application/pdf" onChange={handleUpload} />
              {invoice && <p>Uppladdad: {invoice.name}</p>}
            </div>

            <div className="space-y-2">
              <label className="font-semibold">Skapa verifikation:</label>
              <Input
                placeholder="Datum"
                value={entry.date}
                onChange={(e) => setEntry({ ...entry, date: e.target.value })}
              />
              <Textarea
                placeholder="Beskrivning"
                value={entry.description}
                onChange={(e) => setEntry({ ...entry, description: e.target.value })}
              />
              <Input
                placeholder="Debet (konto och belopp)"
                value={entry.debit}
                onChange={(e) => setEntry({ ...entry, debit: e.target.value })}
              />
              <Input
                placeholder="Kredit (konto och belopp)"
                value={entry.credit}
                onChange={(e) => setEntry({ ...entry, credit: e.target.value })}
              />
              <Button onClick={handleCreateEntry}>Spara verifikation</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}